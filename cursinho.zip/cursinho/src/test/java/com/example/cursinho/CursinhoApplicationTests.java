package com.example.cursinho;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CursinhoApplicationTests {

	@Test
	void contextLoads() {
	}

}
